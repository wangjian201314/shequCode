//
//  CWMineViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWMineViewController.h"
#import "CWMineCell.h"
#import "FacebackViewController.h"
#import "ModifyPWDViewController.h"
#import "CWNewsViewController.h"
#import "LoginViewController.h"
@interface CWMineViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_imgdata;
    NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UIImageView *headimg;
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UIView *topview;

@end

@implementation CWMineViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
        NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
        if(!autLogin || ![autLogin isEqual:@(1)]){
            self.namelb.text=[NSString stringWithFormat:@"点击登录"];
          
        }else{
           
            self.namelb.text=[NSString stringWithFormat:@"业主:%@",@"刘先生"];
        }
    }else{
        self.namelb.text=[NSString stringWithFormat:@"点击登录"];
       
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"我的" leftButtonShow:NO rightButtom:nil];
    _imgdata=@[@"gonggao",@"mima",@"yijian",@"tuichu"];
    _datasource=@[@"社区公告",@"修改密码",@"意见反馈",@"退出"];
    self.topview.layer.masksToBounds=YES;
    self.topview.layer.cornerRadius=8;
    _tableview.delegate=self;
    _tableview.dataSource=self;
    _tableview.showsVerticalScrollIndicator=NO;
    _tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [_tableview registerNib:[UINib nibWithNibName:@"CWMineCell" bundle:nil] forCellReuseIdentifier:@"CWMineCell"];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(recognize)];
    [self.headimg addGestureRecognizer:tap];
    
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    CWMineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CWMineCell"];
    
    if(cell == nil) {
        cell = [[CWMineCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CWMineCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.img.image=[UIImage imageNamed:_imgdata[indexPath.row]];
    cell.textlb.text=_datasource[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}
#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:{
            CWNewsViewController *vc=[CWNewsViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 1:{
            
            NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
            if(!autLogin || ![autLogin isEqual:@(1)]){
                LoginViewController *login=[LoginViewController new];
                [self.navigationController presentViewController:login animated:YES completion:nil];
            }else{
                ModifyPWDViewController *vc=[ModifyPWDViewController new];
                [self pushViewController:vc];
            }

           
        }
            
            break;
            
        case 2:{
            NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
            if(!autLogin || ![autLogin isEqual:@(1)]){
                LoginViewController *login=[LoginViewController new];
                [self.navigationController presentViewController:login animated:YES completion:nil];
            }else{
                FacebackViewController *vc=[FacebackViewController new];
                [self pushViewController:vc];
            }
        }
            
            break;
        case 3:{
            NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
            if(!autLogin || ![autLogin isEqual:@(1)]){
                [SVProgressHUD showErrorWithStatus:@"请先登录！"];
            }else{
                [SVProgressHUD showWithStatus:@"退出登录..."];
                 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                    LoginViewController *login=[LoginViewController new];
                    [self.navigationController presentViewController:login animated:YES completion:nil];
                    [[NSUserDefaults standardUserDefaults]setObject:@(0) forKey:@"autologin"];
                    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"username"];
                    
                    
                });
            }
        }
            
            break;
            
        default:
            break;
    }
    
}



#pragma mark--更换头像
- (void)recognize{
    
    NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
    if(!autLogin || ![autLogin isEqual:@(1)]){
        LoginViewController *login=[LoginViewController new];
        [self.navigationController presentViewController:login animated:YES completion:nil];
    }else{
        UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
        sheet.delegate=self;
        [sheet showInView:self.view];
    }
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
    
    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [self presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    self.headimg.image=[image circleImage];
    [self saveImage:image withname:@"headimg"];
}

- (void)saveImage:(UIImage *)img withname:(NSString *)name{
    
    NSData *imgdata=UIImageJPEGRepresentation(img, 0.5);
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:name];
    BOOL ishave= [imgdata writeToFile:path atomically:NO];
    if(ishave){
        
    }
    
}

@end
