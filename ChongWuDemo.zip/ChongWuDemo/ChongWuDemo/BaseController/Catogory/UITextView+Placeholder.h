//
//  UITextView+Placeholder.h
//  GZZSWY
//
//  Created by wangjian on 2018/9/14.
//  Copyright © 2018年 sandyrilla. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (Placeholder)

- (void)setPlaceHolder:(NSString *)placeHolder;

@property (nonatomic, copy) UILabel *placeHolderStr;
@end
