//
//  UITextView+Placeholder.m
//  GZZSWY
//
//  Created by wangjian on 2018/9/14.
//  Copyright © 2018年 sandyrilla. All rights reserved.
//

#import "UITextView+Placeholder.h"
#import <objc/runtime.h>

@implementation UITextView (Placeholder)


- (void)setPlaceHolder:(NSString *)placeHolder {
    
    if(!self.placeHolderStr){
        
        self.placeHolderStr = [[UILabel alloc] init];
        self.placeHolderStr.text = placeHolder;
        self.placeHolderStr.numberOfLines = 0;
        self.placeHolderStr.textColor = [UIColor lightGrayColor];
        [self.placeHolderStr sizeToFit];
        [self addSubview:self.placeHolderStr];
        self.placeHolderStr.font = self.font;
        [self setValue:self.placeHolderStr forKey:@"_placeholderLabel"];
    }
    
}

- (void)setPlaceHolderStr:(UILabel *)placeHolderStr{
    
    objc_setAssociatedObject(self, @"placeHolderStr", placeHolderStr, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UILabel *)placeHolderStr{
    
    return objc_getAssociatedObject(self, @"placeHolderStr");
}

@end
