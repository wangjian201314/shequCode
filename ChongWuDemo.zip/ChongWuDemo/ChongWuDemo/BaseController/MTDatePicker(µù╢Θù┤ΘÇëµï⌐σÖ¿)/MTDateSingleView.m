//
//  MTDateSingleView.m
//  GDWWNOP
//
//  Created by kingste on 2017/6/6.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "MTDateSingleView.h"

#define selfHeight 260
#define toolBarHeight 44
#define kPickerSize self.datePicker.frame.size

#define MAXYEAR 9999
#define MINYEAR 0

@interface MTDateSingleView () <UIPickerViewDelegate,UIPickerViewDataSource,UIGestureRecognizerDelegate> {
    /** 控件 */
    UIView * _backBlackground;
    UIView * _toolsBar;
    UIView * _bottomView;
    UIDatePicker * _timeYearPicker;//temp
    
    //日期存储数组
    NSMutableArray *_yearArray;
    NSMutableArray *_monthArray;
    NSMutableArray *_dayArray;
    NSMutableArray *_hourArray;
    NSMutableArray *_minuteArray;
    NSString *_dateFormatter;
    
    //记录位置
    NSInteger yearIndex;
    NSInteger monthIndex;
    NSInteger dayIndex;
    NSInteger hourIndex;
    NSInteger minuteIndex;
    
    NSInteger preRow;
    
    BOOL _haveShow;
    
    NSDate *_startDate;
}

@property (nonatomic,strong)UIPickerView *datePicker;
@property (nonatomic, retain) NSDate *scrollToDate;
@property (nonatomic,assign)MTDateStyle datePickerStyle;

@end

@implementation MTDateSingleView

- (instancetype)init {
    self = [super init];
    return self;
}

- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle delegate:(id)delegate {
    self = [super init];
    if (self) {
        self.datePickerStyle = datePickerStyle;
        switch (datePickerStyle) {
            case DateStyleYearMonthDayHourMinute:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
            case DateStyleYearMonthDayHour:
                _dateFormatter = @"yyyy-MM-dd HH";
                break;
            case DateStyleYearMonthDay:
                _dateFormatter = @"yyyy-MM-dd";
                break;
            case DateStyleYearMonth:
                _dateFormatter = @"yyyy-MM";
                break;
            case DateStyleYear:
                _dateFormatter = @"yyyy";
                break;
            case DateStyleMonthDay:
                _dateFormatter = @"yyyy-MM-dd";
                break;
            case DateStyleHourMinute:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
                
            default:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
        }
        
        [self setupUI];
        [self defaultConfig];
        
        if (delegate) {
            self.delegate = delegate;
        }
    }
    return self;
}

- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle DateHandler:(DateHandler)dateHandler {
    self = [super init];
    if (self) {
        self.datePickerStyle = datePickerStyle;
        switch (datePickerStyle) {
            case DateStyleYearMonthDayHourMinute:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
            case DateStyleYearMonthDayHour:
                _dateFormatter = @"yyyy-MM-dd HH";
                break;
            case DateStyleYearMonthDay:
                _dateFormatter = @"yyyy-MM-dd";
                break;
            case DateStyleYearMonth:
                _dateFormatter = @"yyyy-MM";
                break;
            case DateStyleYear:
                _dateFormatter = @"yyyy";
                break;
            case DateStyleMonthDay:
                _dateFormatter = @"yyyy-MM-dd";
                break;
            case DateStyleHourMinute:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
            default:
                _dateFormatter = @"yyyy-MM-dd HH:mm";
                break;
        }
        
        [self setupUI];
        [self defaultConfig];
        
        if (dateHandler) {
            self.dateHandler = dateHandler;
        }
    }
    return self;
}

- (instancetype)initWithDateHandler:(DateHandler)dateHandler {
    self = [super init];
    if (dateHandler) {
        self.dateHandler = dateHandler;
    }
    
    return self;
}


- (void)setupUI {
    _haveShow = NO;
    
    //self
    self.backgroundColor = [UIColor whiteColor];
    self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-selfHeight, [UIScreen mainScreen].bounds.size.width, selfHeight);
    
    
    //backBlackground
    _backBlackground = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    _backBlackground.backgroundColor = [UIColor blackColor];
    _backBlackground.alpha = 0.5;
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismiss)];
    _backBlackground.userInteractionEnabled = YES;
    [_backBlackground addGestureRecognizer:tap];
    
    
    //toolsBar
    _toolsBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, toolBarHeight)];
    _toolsBar .backgroundColor = [UIColor colorWithHexString:@"#0085CE"];
    [self addSubview:_toolsBar];
    
    //btns,label
    UIButton * CancelBtn =[UIButton buttonWithType:UIButtonTypeCustom];
    [CancelBtn setTitle:@"取消" forState:0];
    [CancelBtn setTitleColor:[UIColor whiteColor] forState:0];
    CancelBtn.titleLabel.font =[UIFont systemFontOfSize:14];
    [CancelBtn addTarget:self action:@selector(TimeInputCancelBtn) forControlEvents:UIControlEventTouchUpInside];
    CancelBtn.frame =CGRectMake(0, 0, 60, toolBarHeight);
    [_toolsBar addSubview:CancelBtn];
    UILabel * TimeInputNameLab =[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(CancelBtn.frame), 0, [UIScreen mainScreen].bounds.size.width-120, toolBarHeight)];
    TimeInputNameLab.font =[UIFont systemFontOfSize:14];
    TimeInputNameLab.textColor =[UIColor darkGrayColor];
    TimeInputNameLab.textAlignment = NSTextAlignmentCenter;
    [_toolsBar addSubview:TimeInputNameLab];
    UIButton * OKBtn =[UIButton buttonWithType:UIButtonTypeCustom];
    [OKBtn setTitle:@"完成" forState:0];
    OKBtn.titleLabel.font =[UIFont systemFontOfSize:14];
    [OKBtn setTitleColor:[UIColor whiteColor] forState:0];
    [OKBtn addTarget:self action:@selector(TimeInputOKBtn) forControlEvents:UIControlEventTouchUpInside];
    OKBtn.frame =CGRectMake([UIScreen mainScreen].bounds.size.width-60, 0, 60, toolBarHeight);
    [_toolsBar addSubview:OKBtn];
    
    //_bottomView.datePicker
    CGRect rect = self.bounds;
    _bottomView = [[UIView alloc]initWithFrame:CGRectMake(rect.origin.x, rect.origin.y+toolBarHeight, rect.size.width, rect.size.height-toolBarHeight)];
    _bottomView.backgroundColor =[UIColor whiteColor];
     [self addSubview:_bottomView];
    
    _datePicker = [[UIPickerView alloc] initWithFrame:_bottomView.bounds];
    _datePicker.showsSelectionIndicator = YES;
    _datePicker.delegate = self;
    _datePicker.dataSource = self;
    [_bottomView addSubview:_datePicker];
}

-(void)defaultConfig {
    
    if (!_scrollToDate) {
        _scrollToDate = [NSDate date];
    }
    
    
    //循环滚动时需要用到
    preRow = (self.scrollToDate.year-MINYEAR)*12+self.scrollToDate.month-1;
    
    //设置年月日时分数据
    _yearArray = [self setArray:_yearArray];
    _monthArray = [self setArray:_monthArray];
    _dayArray = [self setArray:_dayArray];
    _hourArray = [self setArray:_hourArray];
    _minuteArray = [self setArray:_minuteArray];
    
    for (int i=0; i<60; i++) {
        NSString *num = [NSString stringWithFormat:@"%02d",i];
        if (0<i && i<=12)
            [_monthArray addObject:num];
        if (i<24)
            [_hourArray addObject:num];
        [_minuteArray addObject:num];
    }
    for (NSInteger i=MINYEAR; i<MAXYEAR; i++) {
        NSString *num = [NSString stringWithFormat:@"%ld",(long)i];
        [_yearArray addObject:num];
    }
    
    //最大最小限制
    if (!self.maxLimitDate) {
        self.maxLimitDate = [NSDate date:@"9999-12-31 23:59" WithFormat:@"yyyy-MM-dd HH:mm"];
    }
    //最小限制
    if (!self.minLimitDate) {
        self.minLimitDate = [NSDate date:@"0000-01-01 00:00" WithFormat:@"yyyy-MM-dd HH:mm"];
    }
}

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        _haveShow = NO;
        
        //        CGFloat selfHeight = 320;
        
        //self
        self.backgroundColor = [UIColor whiteColor];
        self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-selfHeight, [UIScreen mainScreen].bounds.size.width, selfHeight);
        
        
        //backBlackground
        _backBlackground = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
        _backBlackground.backgroundColor = [UIColor blackColor];
        _backBlackground.alpha = 0.5;
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismiss)];
        _backBlackground.userInteractionEnabled = YES;
        [_backBlackground addGestureRecognizer:tap];
        
        
        //toolsBar
        _toolsBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, toolBarHeight)];
        _toolsBar .backgroundColor = [UIColor groupTableViewBackgroundColor];
        [self addSubview:_toolsBar];
        
        //btns,label
        UIButton * CancelBtn =[UIButton buttonWithType:UIButtonTypeCustom];
        [CancelBtn setTitle:@"取消" forState:0];
        [CancelBtn setTitleColor:[UIColor darkGrayColor] forState:0];
        CancelBtn.titleLabel.font =[UIFont systemFontOfSize:14];
        [CancelBtn addTarget:self action:@selector(TimeInputCancelBtn) forControlEvents:UIControlEventTouchUpInside];
        CancelBtn.frame =CGRectMake(0, 0, 60, toolBarHeight);
        [_toolsBar addSubview:CancelBtn];
        UILabel * TimeInputNameLab =[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(CancelBtn.frame), 0, [UIScreen mainScreen].bounds.size.width-120, toolBarHeight)];
        TimeInputNameLab.font =[UIFont systemFontOfSize:14];
        TimeInputNameLab.textColor =[UIColor darkGrayColor];
        TimeInputNameLab.textAlignment = NSTextAlignmentCenter;
        [_toolsBar addSubview:TimeInputNameLab];
        UIButton * OKBtn =[UIButton buttonWithType:UIButtonTypeCustom];
        [OKBtn setTitle:@"完成" forState:0];
        OKBtn.titleLabel.font =[UIFont systemFontOfSize:14];
        [OKBtn setTitleColor:[UIColor darkGrayColor] forState:0];
        [OKBtn addTarget:self action:@selector(TimeInputOKBtn) forControlEvents:UIControlEventTouchUpInside];
        OKBtn.frame =CGRectMake([UIScreen mainScreen].bounds.size.width-60, 0, 60, toolBarHeight);
        [_toolsBar addSubview:OKBtn];
        
        //TimeYearPicker
        _timeYearPicker = [[UIDatePicker alloc]initWithFrame:CGRectMake(0, toolBarHeight, [UIScreen mainScreen].bounds.size.width, selfHeight-toolBarHeight)];
        _timeYearPicker.datePickerMode = UIDatePickerModeDate;
        _timeYearPicker.backgroundColor = [UIColor whiteColor];
        _timeYearPicker.locale = [[NSLocale alloc]initWithLocaleIdentifier:@"zh_CN"];
        [_timeYearPicker setDate:[NSDate date] animated:YES];
        [_timeYearPicker setMinimumDate:[NSDate distantPast]];
        [_timeYearPicker addTarget:self action:@selector(datePickerValueChanged:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:_timeYearPicker];
    }
    return self;
}

#pragma mark - Acrions
- (void)datePickerValueChanged:(UIDatePicker *)datePicker {
    
}

- (void)TimeInputCancelBtn {
    [self dismiss];
}

- (void)TimeInputOKBtn {
    _date = [self.scrollToDate dateWithFormatter:_dateFormatter];
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(MTDateSingleView:didSelectedDate:)]) {
            [self.delegate MTDateSingleView:self didSelectedDate:_date];
        }
    }else{
        self.dateHandler(_date);
    }
    [self dismiss];
}

#pragma mark - Public
- (void)show {
    if (_haveShow) {
        return;
    }
    _haveShow = YES;
    
    UIView * superView = [UIApplication sharedApplication].keyWindow;
    
    __weak typeof(self) weakSelf = self;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [superView addSubview:_backBlackground];
        [superView addSubview:self];
        
        CGRect correctRect  = self.frame;
        CGRect tempRect     = self.frame;
        tempRect.origin.y   = [UIScreen mainScreen].bounds.size.height;
        
        weakSelf.frame = tempRect;
        
        
        _backBlackground.alpha = 0.0;
        [UIView animateWithDuration:0.2 animations:^{
            _backBlackground.alpha = 0.5;
            weakSelf.frame = correctRect;
            [self layoutIfNeeded];
        } completion:^(BOOL finished) {
            
        }];
    });
}

- (void)dismiss {
    if (_haveShow == NO) {
        return;
    }
    _haveShow = NO;
    
    __weak typeof(self) weakSelf = self;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        CGRect correctRect  = weakSelf.frame;
        CGRect tempRect     = weakSelf.frame;
        tempRect.origin.y   = [UIScreen mainScreen].bounds.size.height;
        
        //        self.frame = tempRect;
        
        [UIView animateWithDuration:0.2 animations:^{
            _backBlackground.alpha = 0;
            weakSelf.frame = tempRect;
        } completion:^(BOOL finished) {
            weakSelf.frame = correctRect;
            
            [weakSelf removeFromSuperview];
            [_backBlackground removeFromSuperview];
        }];
    });
}

- (NSMutableArray *)setArray:(id)mutableArray {
    if (mutableArray)
        [mutableArray removeAllObjects];
    else
        mutableArray = [NSMutableArray array];
    return mutableArray;
}

#pragma mark - UIPickerViewDelegate,UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    switch (self.datePickerStyle) {
        case DateStyleYearMonthDayHourMinute:
            [self addLabelWithName:@[@"年",@"月",@"日",@"时",@"分"]];
            return 5;
        case DateStyleYearMonthDayHour:
            [self addLabelWithName:@[@"年",@"月",@"日",@"时"]];
            return 4;
        case DateStyleYearMonthDay:
            [self addLabelWithName:@[@"年",@"月",@"日"]];
            return 3;
        case DateStyleYearMonth:
            [self addLabelWithName:@[@"月",@"日"]];
            return 2;
        case DateStyleYear:
            [self addLabelWithName:@[@"年"]];
            return 1;
        case DateStyleMonthDay:
            [self addLabelWithName:@[@"月",@"日"]];
            return 2;
        case DateStyleHourMinute:
            [self addLabelWithName:@[@"时",@"分"]];
            return 2;
        default:
            return 0;
    }
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    NSArray *numberArr = [self getNumberOfRowsInComponent];
    return [numberArr[component] integerValue];
}

-(NSArray *)getNumberOfRowsInComponent {
    
    NSInteger yearNum = _yearArray.count;
    NSInteger monthNum = _monthArray.count;
    NSInteger dayNum = [self DaysfromYear:[_yearArray[yearIndex] integerValue] andMonth:[_monthArray[monthIndex] integerValue]];
    NSInteger hourNum = _hourArray.count;
    NSInteger minuteNUm = _minuteArray.count;
    
    NSInteger timeInterval = MAXYEAR - MINYEAR;
    
    switch (self.datePickerStyle) {
        case DateStyleYearMonthDayHourMinute:
            return @[@(yearNum),@(monthNum),@(dayNum),@(hourNum),@(minuteNUm)];
            break;
        case DateStyleYearMonthDayHour:
            return @[@(yearNum),@(monthNum),@(dayNum),@(hourNum)];
            break;
        case DateStyleYearMonthDay:
            return @[@(yearNum),@(monthNum),@(dayNum)];
            break;
        case DateStyleYearMonth:
            return @[@(yearNum),@(monthNum)];
            break;
        case DateStyleYear:
            return @[@(yearNum)];
            break;
        case DateStyleMonthDay:
            return @[@(monthNum),@(dayNum)];
            break;
        case DateStyleHourMinute:
            return @[@(hourNum),@(minuteNUm)];
            break;
        default:
            return @[];
            break;
    }
    
}

-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 40;
}


-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *customLabel = (UILabel *)view;
    if (!customLabel) {
        customLabel = [[UILabel alloc] init];
        customLabel.textAlignment = NSTextAlignmentCenter;
        [customLabel setFont:[UIFont systemFontOfSize:17]];
    }
    NSString *title;
    
    switch (self.datePickerStyle) {
        case DateStyleYearMonthDayHourMinute:
            if (component==0) {
                title = _yearArray[row];
            }
            if (component==1) {
                title = _monthArray[row];
            }
            if (component==2) {
                title = _dayArray[row];
            }
            if (component==3) {
                title = _hourArray[row];
            }
            if (component==4) {
                title = _minuteArray[row];
            }
            break;
        case DateStyleYearMonthDayHour:
            if (component==0) {
                title = _yearArray[row];
            }
            if (component==1) {
                title = _monthArray[row];
            }
            if (component==2) {
                title = _dayArray[row];
            }
            if (component==3) {
                title = _hourArray[row];
            }
            break;
        case DateStyleYearMonthDay:
            if (component==0) {
                title = _yearArray[row];
            }
            if (component==1) {
                title = _monthArray[row];
            }
            if (component==2) {
                title = _dayArray[row];
            }
            break;
        case DateStyleYearMonth:
            if (component==0) {
                title = _yearArray[row];
            }
            if (component==1) {
                title = _monthArray[row];
            }
            break;
        case DateStyleYear:
            if (component==0) {
                title = _yearArray[row];
            }
            break;
        case DateStyleMonthDay:
            if (component==0) {
                title = _monthArray[row];
            }
            if (component==1) {
                title = _dayArray[row];
            }
            break;
        case DateStyleHourMinute:
            if (component==0) {
                title = _hourArray[row];
            }
            if (component==1) {
                title = _minuteArray[row];
            }
            break;
        default:
            title = @"";
            break;
    }
    
    customLabel.text = title;
    customLabel.textColor = [UIColor blackColor];
    return customLabel;
    
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    switch (self.datePickerStyle) {
        case DateStyleYearMonthDayHourMinute:{
            
            if (component == 0) {
                yearIndex = row;
            }
            if (component == 1) {
                monthIndex = row;
            }
            if (component == 2) {
                dayIndex = row;
            }
            if (component == 3) {
                hourIndex = row;
            }
            if (component == 4) {
                minuteIndex = row;
            }
            if (component == 0 || component == 1){
                [self DaysfromYear:[_yearArray[yearIndex] integerValue] andMonth:[_monthArray[monthIndex] integerValue]];
                if (_dayArray.count-1<dayIndex) {
                    dayIndex = _dayArray.count-1;
                }
                
            }
        }
            break;
            
            
        case DateStyleYearMonthDayHour:{
            
            if (component == 0) {
                yearIndex = row;
            }
            if (component == 1) {
                monthIndex = row;
            }
            if (component == 2) {
                dayIndex = row;
            }
            if (component == 3) {
                hourIndex = row;
            }
            if (component == 0 || component == 1){
                [self DaysfromYear:[_yearArray[yearIndex] integerValue] andMonth:[_monthArray[monthIndex] integerValue]];
                if (_dayArray.count-1<dayIndex) {
                    dayIndex = _dayArray.count-1;
                }
                
            }
        }
            break;
            
            
        case DateStyleYearMonthDay:{
            
            
            if (component == 0) {
                yearIndex = row;
            }
            if (component == 1) {
                monthIndex = row;
            }
            if (component == 2) {
                dayIndex = row;
            }
            if (component == 0 || component == 1){
                [self DaysfromYear:[_yearArray[yearIndex] integerValue] andMonth:[_monthArray[monthIndex] integerValue]];
                if (_dayArray.count-1<dayIndex) {
                    dayIndex = _dayArray.count-1;
                }
                
            }
        }
            break;
            
        case DateStyleYearMonth:{
            if (component == 0) {
                yearIndex = row;
            }
            if (component == 1) {
                monthIndex = row;
            }
        }
            break;
            
        case DateStyleYear:{
            if (component == 0) {
                yearIndex = row;
            }
        }
            break;
            
        case DateStyleMonthDay:{
            if (component == 0) {
                monthIndex = row;
            }
            if (component == 1) {
                dayIndex = row;
            }
            if (component == 0){
                [self DaysfromYear:[_yearArray[yearIndex] integerValue] andMonth:[_monthArray[monthIndex] integerValue]];
                if (_dayArray.count-1<dayIndex) {
                    dayIndex = _dayArray.count-1;
                }
            }
        }
            break;
        case DateStyleHourMinute:{
            if (component == 0) {
                hourIndex = row;
            }
            if (component == 1) {
                minuteIndex = row;
            }
        }
            break;
            
        default:
            break;
    }
    
    [pickerView reloadAllComponents];
    
    NSString *dateStr = [NSString stringWithFormat:@"%@-%@-%@ %@:%@",_yearArray[yearIndex],_monthArray[monthIndex],_dayArray[dayIndex],_hourArray[hourIndex],_minuteArray[minuteIndex]];
    
    self.scrollToDate = [[NSDate date:dateStr WithFormat:@"yyyy-MM-dd HH:mm"] dateWithFormatter:_dateFormatter];
    
    if ([self.scrollToDate compare:self.minLimitDate] == NSOrderedAscending) {
        self.scrollToDate = self.minLimitDate;
        [self getNowDate:self.minLimitDate animated:YES];
    }else if ([self.scrollToDate compare:self.maxLimitDate] == NSOrderedDescending){
        self.scrollToDate = self.maxLimitDate;
        [self getNowDate:self.maxLimitDate animated:YES];
    }
    
    _startDate = self.scrollToDate;
    
}

-(void)addLabelWithName:(NSArray *)nameArr {
    for (id subView in _bottomView.subviews) {
        if ([subView isKindOfClass:[UILabel class]]) {
            [subView removeFromSuperview];
        }
    }
    for (int i=0; i<nameArr.count; i++) {
        CGFloat labelX = kPickerSize.width/(nameArr.count*2)+18+kPickerSize.width/nameArr.count*i;
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(labelX, _bottomView.frame.size.height/2-15/2.0, 15, 15)];
        label.text = nameArr[i];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:14];
        label.textColor = [UIColor colorWithHexString:@"#0085CE"];
        label.backgroundColor = [UIColor clearColor];
        [_bottomView addSubview:label];
    }
}

#pragma mark - tools
//通过年月求每月天数
- (NSInteger)DaysfromYear:(NSInteger)year andMonth:(NSInteger)month
{
    NSInteger num_year  = year;
    NSInteger num_month = month;
    
    BOOL isrunNian = num_year%4==0 ? (num_year%100==0? (num_year%400==0?YES:NO):YES):NO;
    switch (num_month) {
        case 1:case 3:case 5:case 7:case 8:case 10:case 12:{
            [self setdayArray:31];
            return 31;
        }
        case 4:case 6:case 9:case 11:{
            [self setdayArray:30];
            return 30;
        }
        case 2:{
            if (isrunNian) {
                [self setdayArray:29];
                return 29;
            }else{
                [self setdayArray:28];
                return 28;
            }
        }
        default:
            break;
    }
    return 0;
}

//设置每月的天数数组
- (void)setdayArray:(NSInteger)num {
    [_dayArray removeAllObjects];
    for (int i=1; i<=num; i++) {
        [_dayArray addObject:[NSString stringWithFormat:@"%02d",i]];
    }
}

//滚动到指定的时间位置
- (void)getNowDate:(NSDate *)date animated:(BOOL)animated {
    if (!date) {
        date = [NSDate date];
    }
    
    [self DaysfromYear:date.year andMonth:date.month];
    
    yearIndex = date.year-MINYEAR;
    monthIndex = date.month-1;
    dayIndex = date.day-1;
    hourIndex = date.hour;
    minuteIndex = date.minute;
    
    //循环滚动时需要用到
    preRow = (self.scrollToDate.year-MINYEAR)*12+self.scrollToDate.month-1;
    
    NSArray *indexArray;
    
    if (self.datePickerStyle == DateStyleYearMonthDayHourMinute)
        indexArray = @[@(yearIndex),@(monthIndex),@(dayIndex),@(hourIndex),@(minuteIndex)];
    if (self.datePickerStyle == DateStyleYearMonthDayHour)
        indexArray = @[@(yearIndex),@(monthIndex),@(dayIndex),@(hourIndex)];
    if (self.datePickerStyle == DateStyleYearMonthDay)
        indexArray = @[@(yearIndex),@(monthIndex),@(dayIndex)];
    if (self.datePickerStyle == DateStyleYearMonth)
        indexArray = @[@(yearIndex),@(monthIndex)];
    if (self.datePickerStyle == DateStyleYear)
        indexArray = @[@(yearIndex)];
    if (self.datePickerStyle == DateStyleMonthDay)
        indexArray = @[@(monthIndex),@(dayIndex)];
    if (self.datePickerStyle == DateStyleHourMinute)
        indexArray = @[@(hourIndex),@(minuteIndex)];
    
    [self.datePicker reloadAllComponents];
    
    for (int i=0; i<indexArray.count; i++) {
        [self.datePicker selectRow:[indexArray[i] integerValue] inComponent:i animated:animated];
    }
}

-(void)setMinLimitDate:(NSDate *)minLimitDate {
    _minLimitDate = minLimitDate;
    if ([_scrollToDate compare:self.minLimitDate] == NSOrderedAscending) {
        _scrollToDate = self.minLimitDate;
    }
    [self getNowDate:self.scrollToDate animated:NO];
}

#pragma mark - Other
-(void)setDate:(NSDate *)date {
    _date = date;
    [self getNowDate:date animated:YES];
}

- (void)dealloc {
    NSLog(@"%s",__func__);
}


@end
