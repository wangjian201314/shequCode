//
//  LoginViewController.m
//  Broadband
//
//  Created by 王健 on 2019/5/19.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "LoginViewController.h"
#import "MTTabBarController.h"
#import "AppDelegate.h"
#import "RegisterViewController.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nametext;
@property (weak, nonatomic) IBOutlet UITextField *pwdtext;
@property (weak, nonatomic) IBOutlet UIButton *namebtn;
@property (weak, nonatomic) IBOutlet UIButton *pwdbnt;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    self.nametext.text=@"15976070261";
//    self.pwdtext.text=@"qwe123";
    self.namebtn.layer.masksToBounds=YES;
//    self.namebtn.layer.borderWidth=0.5;
    self.namebtn.layer.cornerRadius=10;
//    self.namebtn.layer.borderColor=[UIColor colorWithHexString:@"#EA6B50"].CGColor;
    self.pwdbnt.layer.masksToBounds=YES;
    self.pwdbnt.layer.borderWidth=0.5;
    self.pwdbnt.layer.cornerRadius=10;
    self.pwdbnt.layer.borderColor=[UIColor colorWithHexString:@"#EA6B50"].CGColor;
   id ddict= [[NSUserDefaults standardUserDefaults]objectForKey:@"login"];
    if(!ddict){
        NSDictionary *dict=@{@"15976070261":@"qwe123"};
        [[NSUserDefaults standardUserDefaults]setObject:dict forKey:@"login"];
    }
   
}
- (IBAction)loginbtn:(UIButton *)sender {
    
    if([self.nametext.text containsString:@" "]){
        [SVProgressHUD showErrorWithStatus:@"用户名错误"];
        return;
    }
    if(self.nametext.text.length == 0){
        [SVProgressHUD showErrorWithStatus:@"用户名不能为空"];
        return;
    }
    if(self.pwdtext.text.length == 0){
        [SVProgressHUD showErrorWithStatus:@"密码不能为空"];
        return;
    }
    if(![LSFEasy validateMobile:self.nametext.text]){
        
        [SVProgressHUD showErrorWithStatus:@"请输入正确的手机号格式"];
        return;
    }
    if(self.pwdtext.text.length<6||self.pwdtext.text.length>20){
        
        [SVProgressHUD showErrorWithStatus:@"密码(6-20)位"];
        return;
    }
    NSDictionary *dict=[[NSUserDefaults standardUserDefaults]objectForKey:@"login"];
    NSArray *keyarr=[dict allKeys];
    if(![  keyarr containsObject: self.nametext.text  ] || ![self.pwdtext.text isEqualToString: isnull(dict[self.nametext.text])]){
        [SVProgressHUD showErrorWithStatus:@"用户名或者密码错误!"];
        return;
    }
   
    [SVProgressHUD showWithStatus:@"正在登录。。。"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [[NSUserDefaults standardUserDefaults]setObject:@(1) forKey:@"autologin"];
        
        [[NSUserDefaults standardUserDefaults]setObject:self.nametext.text forKey:@"username"];
        MTTabBarController *tabBarController = [[MTTabBarController alloc]init];
        AppDelegate *delegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
        delegate.window.rootViewController = tabBarController;
        
    });
}
- (IBAction)regist:(UIButton *)sender {
    
    RegisterViewController *vc=[RegisterViewController new];
    [self presentViewController:vc animated:YES completion:nil];
}
- (IBAction)backbtn:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
