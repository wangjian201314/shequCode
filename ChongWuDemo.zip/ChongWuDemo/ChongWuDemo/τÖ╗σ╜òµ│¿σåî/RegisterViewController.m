//
//  RegisterViewController.m
//  Broadband
//
//  Created by Mac on 2019/5/23.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nametext;
@property (weak, nonatomic) IBOutlet UITextField *passtext;
@property (weak, nonatomic) IBOutlet UITextField *companytext;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)regist:(UIButton *)sender {
    
    if([self.nametext.text containsString:@" "]){
        [SVProgressHUD showErrorWithStatus:@"账号错误"];
        return;
    }
    if(self.nametext.text.length == 0){
        [SVProgressHUD showErrorWithStatus:@"账号不能为空"];
        return;
    }
    if(self.passtext.text.length == 0){
        [SVProgressHUD showErrorWithStatus:@"密码不能为空"];
        return;
    }
    if(self.companytext.text.length == 0){
//        [SVProgressHUD showErrorWithStatus:@"考勤公司名称不能为空"];
//        return;
    }
    if(![LSFEasy validateMobile:self.nametext.text]){
        
        [SVProgressHUD showErrorWithStatus:@"请输入正确的手机号格式"];
        return;
    }
    if(self.passtext.text.length<6||self.passtext.text.length>20){
        
        [SVProgressHUD showErrorWithStatus:@"密码(6-20)位"];
        return;
    }
    
    [SVProgressHUD showWithStatus:@"正在注册。。。"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [SVProgressHUD showSuccessWithStatus:@"注册成功"];
        NSMutableDictionary *dict=[NSMutableDictionary dictionary];
        dict=[[[NSUserDefaults standardUserDefaults]objectForKey:@"login"] mutableCopy];
        [dict setObject:self.passtext.text forKey:self.nametext.text];
        [[NSUserDefaults standardUserDefaults]setObject:dict forKey:@"login"];
        [[NSUserDefaults standardUserDefaults]setObject:self.companytext.text forKey:@"company"];
        [self dismissViewControllerAnimated:YES completion:nil];
        
    });
    
}
- (IBAction)backbtn:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
