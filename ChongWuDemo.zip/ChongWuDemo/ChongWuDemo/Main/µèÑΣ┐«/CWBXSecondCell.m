//
//  CWBXSecondCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWBXSecondCell.h"

@implementation CWBXSecondCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)photobtn:(UIButton *)sender {
    
    [self recognize];
}



#pragma mark--更换头像
- (void)recognize{
    
    
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
    sheet.delegate=self;
    [sheet showInView:self];
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [[self viewController] presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    [self.photobtn setBackgroundImage:image forState:UIControlStateNormal];
    
}


- (UIViewController*) viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}
@end
