//
//  CWBXTopCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWBXTopCell.h"

@implementation CWBXTopCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
     self.textlb.delegate=self;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    if(self.delegate && [self.delegate respondsToSelector:@selector(Textfieldcell:)]){
        [self.delegate Textfieldcell:self];
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
