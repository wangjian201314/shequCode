//
//  CWBaoXiuViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWBaoXiuViewController.h"
#import "CWBXTopCell.h"
#import "CWBXSecondCell.h"
#import "LoginViewController.h"
@interface CWBaoXiuViewController ()<UITableViewDataSource,UITableViewDelegate,SPAppointCellDelegate>{
    
    NSArray *_datasource;
    NSInteger _numcount;
    NSArray *_imgdata;
    NSMutableDictionary *_uploaddict;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong)UIButton *sendbtn;
@end

@implementation CWBaoXiuViewController

- (UIButton *)sendbtn{
    
    if(!_sendbtn){
        _sendbtn=[[UIButton alloc]initWithFrame:CGRectMake(30, kScreenH-kTabarHeight-70,kScreenW-60, 45)];
        [_sendbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _sendbtn.layer.masksToBounds = YES;
        [_sendbtn setTitle:@"提交物业" forState:UIControlStateNormal];
        [_sendbtn setBackgroundColor:[UIColor colorWithHexString:@"#6495ED"]];
        _sendbtn.layer.cornerRadius = 8.0;
        [_sendbtn addTarget:self action:@selector(upload) forControlEvents:UIControlEventTouchUpInside];
        
        
        
    }
    return _sendbtn;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"我要报修" leftButtonShow:YES rightButtom:nil];
    _uploaddict=[NSMutableDictionary dictionary];
    _datasource=@[@"报修人:",@"联系电话:",@"地址:",@"时间:",@"小区:",@"住房:",@"门牌号"];
    _imgdata=@[@"baoxiurenxinxi",@"icon-anxinqiao-",@"dizhi",@"shijian",@"xiaoqu",@"zhufang",@"menpaihao"];
    _numcount=8;
    [self setUITableview];
    [self.view addSubview:self.sendbtn];
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWBXTopCell" bundle:nil] forCellReuseIdentifier:@"CWBXTopCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWBXSecondCell" bundle:nil] forCellReuseIdentifier:@"CWBXSecondCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
//    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
//    [self.tableview.mj_header beginRefreshing];
}




#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _numcount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==_numcount-1){
        return 200;
    }else{
        return 60;
    }
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==_numcount-1){
        
        static NSString *cellIdentifier = @"CWBXSecondCell";
        
        CWBXSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWBXSecondCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
       
        return cell;
    }else{
        
        static NSString *cellIdentifier = @"CWBXTopCell";
        
        CWBXTopCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWBXTopCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.namelb.text=_datasource[indexPath.row];
        cell.img.image=[UIImage imageNamed:_imgdata[indexPath.row]];
        [cell.textlb setPlaceholder:[NSString stringWithFormat:@"请输入%@",_datasource[indexPath.row]]];
        cell.delegate=self;
        return cell;
        
    }
    
   
}

- (void)Textfieldcell:(CWBXTopCell *)orderEditCell{
    
    NSIndexPath *indexPath = [_tableview indexPathForCell:orderEditCell];
    [_uploaddict setObject:isnull(orderEditCell.textlb.text) forKey:isnull(_datasource[indexPath.row])];
    
    
}

- (void)upload{
    
    for (int i=0; i<_datasource.count-1; i++) {
        
        if([isnull(_uploaddict[_datasource[i]]) isEqualToString:@""]){
            [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"请填写%@",_datasource[i]]];
            return;
        }
    }
    
    NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
    if(!autLogin || ![autLogin isEqual:@(1)]){
        LoginViewController *login=[LoginViewController new];
        [self.navigationController presentViewController:login animated:YES completion:nil];
        return;
    }
    [SVProgressHUD showWithStatus:@"正在提交..."];
    NSArray *temparr=[[_uploaddict allValues] copy];
    
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [SVProgressHUD showSuccessWithStatus:@"提交成功"];
        
        [self backAction];
    });
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

