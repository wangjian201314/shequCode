//
//  CWSCTableviewCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWSCTableviewCell.h"

@implementation CWSCTableviewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.selectbtn.layer.masksToBounds=YES;
    self.selectbtn.layer.cornerRadius=8;
    self.img.layer.masksToBounds=YES;
    self.img.layer.cornerRadius=8;
}
- (IBAction)duihuanbtn:(UIButton *)sender {
    
    UIAlertView *alter=[[UIAlertView alloc]initWithTitle:@"提示" message:@"确定要用积分兑换商品?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alter.delegate=self;
    alter.tag=10;
    [alter show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==11){
        return;
    }
    if(buttonIndex==1){
       
        UIAlertView *alter=[[UIAlertView alloc]initWithTitle:@"提示" message:@"对不起，您的积分不足哦!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"ok", nil];
        alter.delegate=self;
        alter.tag=11;
        [alter show];

    }else{
        
    }
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
