//
//  CWSCViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWSCViewController.h"
#import "CWSCTableviewCell.h"
#import "CWSCTopViewCell.h"
@interface CWSCViewController ()<UITableViewDataSource,UITableViewDelegate>{
    
    NSArray *_datasource;
    NSInteger _numcount;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation CWSCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"社区商城" leftButtonShow:YES rightButtom:nil];
    [self setUITableview];
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWSCTableviewCell" bundle:nil] forCellReuseIdentifier:@"CWSCTableviewCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWSCTopViewCell" bundle:nil] forCellReuseIdentifier:@"CWSCTopViewCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [self.tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self.tableview.mj_header endRefreshing];
        _numcount=4;
        [self setUpData];
    });
}

- (void)setUpData{
    
    _datasource=@[@{@"img":@"jifen1",
                    @"title":@"商品名称:冰箱",
                    @"jifen":@"商品积分:2500",
                    @"date":@"商品库存:10",
                    },
                  @{@"img":@"jifen2",
                    @"title":@"商品名称:热水器",
                     @"jifen":@"商品积分:1900",
                    @"date":@"商品库存:5",
                    },
                  @{@"img":@"jifen3",
                    @"title":@"商品名称:耳机",
                     @"jifen":@"商品积分:500",
                    @"date":@"商品库存:15",
                    }];
    [self.tableview reloadData];
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _numcount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==0){
        return 40;
    }else{
         return 100;
    }
   
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==0){
        
        static NSString *cellIdentifier = @"CWSCTopViewCell";
        
        CWSCTopViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWSCTopViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
       
        return cell;
    }else{
        static NSString *cellIdentifier = @"CWSCTableviewCell";
        
        CWSCTableviewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWSCTableviewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        NSDictionary *dict=_datasource[indexPath.row-1];
        cell.img.image=[UIImage imageNamed:dict[@"img"]];
        cell.titlelb.text=dict[@"title"];
        cell.secondlb.text=dict[@"jifen"];
        cell.datelb.text=dict[@"date"];
        return cell;
    }
    
   
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
