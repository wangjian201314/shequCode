//
//  CWMainTopCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWMainTopCell.h"

@implementation CWMainTopCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setUI];
}

- (void)setUI{
    
    _imgdata=@[@"wuyeweiixu",@"wuyebanner1",@"banner222",@"banner333"];
    [self addSubview:self.scrollview];
    _control=[[UIPageControl alloc]initWithFrame:CGRectMake((kScreenW-80)/2, 180, 80, 20)];
    _control.numberOfPages=4;
    _control.currentPageIndicatorTintColor=[UIColor redColor];
    [self addSubview:_control];
}
- (UIScrollView *)scrollview{
    
    if(!_scrollview){
        _scrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 200)];
        _scrollview.contentSize=CGSizeMake(kScreenW*_imgdata.count, 0);
        [_scrollview setPagingEnabled:YES];
        [_scrollview setDelegate:self];
        [_scrollview setBounces:NO];
        [_scrollview setUserInteractionEnabled:YES];
        [_scrollview setShowsHorizontalScrollIndicator:NO];
        [_scrollview setShowsVerticalScrollIndicator:NO];
        for(int i=0;i<_imgdata.count;i++){
            
            UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(i*kScreenW, 0, kScreenW, 200)];
            img.image=[UIImage imageNamed:_imgdata[i]];
            img.userInteractionEnabled=YES;
            UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, kScreenW, kScHeight)];
            [img addSubview:btn];
            btn.tag=10+i;
            
            [_scrollview addSubview:img];
        }
        
    }
    return _scrollview;
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    _control.currentPage=scrollView.contentOffset.x/kScreenW;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
