//
//  CWMainTopCell.h
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWMainTopCell : UITableViewCell{
    
    NSArray *_imgdata;
}
@property(nonatomic,strong)UIScrollView *scrollview;
@property(nonatomic,strong)UIPageControl *control;
@end

NS_ASSUME_NONNULL_END
