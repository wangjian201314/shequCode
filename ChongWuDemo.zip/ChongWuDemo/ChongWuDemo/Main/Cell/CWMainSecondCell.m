//
//  CWMainSecondCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWMainSecondCell.h"
#import "CWMainCollectCell.h"
#import "UIImage+Exction.h"
#import "CWBaoXiuViewController.h"
#import "CWNewsViewController.h"
#import "CWSCViewController.h"
@implementation CWMainSecondCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _topimg=@[@"lsf30",@"lsf31",@"lsf32"];
    _topdata=@[@"社区公告",@"物业报修",@"社区商城"];
    [self initCollectionView];
}

- (void)initCollectionView {
    flowLayout_ = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout_ setScrollDirection:UICollectionViewScrollDirectionVertical];
    self.collectionview.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionview.showsHorizontalScrollIndicator = NO;
    self.collectionview.delaysContentTouches = YES;
    self.collectionview.pagingEnabled = NO;
    [self.collectionview setDataSource:self];
    [self.collectionview setDelegate:self];
    self.collectionview.backgroundColor=[UIColor whiteColor];
    [self.collectionview registerNib:[UINib nibWithNibName:@"CWMainCollectCell" bundle:nil] forCellWithReuseIdentifier:@"CWMainCollectCell"];
    
}

//设置每个item的尺寸
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    return CGSizeMake(kScWidth/3, 100);
    
}

//设置每个item的UIEdgeInsets
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0,0,0,0);
}

//设置每个item水平间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}


//设置每个item垂直间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _topdata.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CWMainCollectCell *cell = (CWMainCollectCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"CWMainCollectCell" forIndexPath:indexPath];
    cell.textlb.text=_topdata[indexPath.row];
    cell.img.image=[[UIImage imageNamed:_topimg[indexPath.row]] circleImage];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==0){
        
        CWNewsViewController *vc=[CWNewsViewController new];
        vc.hidesBottomBarWhenPushed=YES;
        [[self viewController].navigationController pushViewController:vc animated:YES];
        
    }else if(indexPath.row==1){
        
        CWBaoXiuViewController *vc=[CWBaoXiuViewController new];
         vc.hidesBottomBarWhenPushed=YES;
        [[self viewController].navigationController pushViewController:vc animated:YES];
    }else{
        
        CWSCViewController *vc=[CWSCViewController new];
         vc.hidesBottomBarWhenPushed=YES;
        [[self viewController].navigationController pushViewController:vc animated:YES];
    }
}


- (UIViewController*) viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}
@end
