//
//  CWNewsCell.h
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWNewsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imglb;
@property (weak, nonatomic) IBOutlet UILabel *titlelb;
@property (weak, nonatomic) IBOutlet UILabel *datelb;

@end

NS_ASSUME_NONNULL_END
