//
//  CWNewsViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWNewsViewController.h"
#import "CWNewsCell.h"
@interface CWNewsViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation CWNewsViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"社区公告" leftButtonShow:YES rightButtom:nil];
    [self setUITableview];
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWNewsCell" bundle:nil] forCellReuseIdentifier:@"CWNewsCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [self.tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self.tableview.mj_header endRefreshing];
       
        [self setUpData];
    });
}

- (void)setUpData{
    
    _datasource=@[@{@"img":@"gonggao1",
                    @"title":@"团团圆圆过中秋”手工制作冰皮月饼的活动",
                    @"date":@"2019-09-12",
                    },
                  @{@"img":@"gonggao2",
                    @"title":@"中秋之夜，社区将举行联谊活动",
                    @"date":@"2019-09-11",
                    },
                  @{@"img":@"gonggao3",
                    @"title":@"明天下午社区举办篮球比赛活动",
                    @"date":@"2019-09-11",
                    }];
    [self.tableview reloadData];
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
   
        
        static NSString *cellIdentifier = @"CWNewsCell";
        
        CWNewsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWNewsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
    NSDictionary *dict=_datasource[indexPath.row];
    cell.imglb.image=[[UIImage imageNamed:dict[@"img"]]circleImage];
    cell.titlelb.text=dict[@"title"];
    cell.datelb.text=dict[@"date"];
    return cell;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
