//
//  CWDetailViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWDetailViewController.h"

@interface CWDetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *topimg;
@property (weak, nonatomic) IBOutlet UITextView *textview;

@end

@implementation CWDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setNaviTitle:_dict[@"title"] leftButtonShow:YES rightButtom:nil];
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        self.textview.text=_dict[@"detail"];
        self.topimg.image=[UIImage imageNamed:_dict[@"img"]];
    });
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
