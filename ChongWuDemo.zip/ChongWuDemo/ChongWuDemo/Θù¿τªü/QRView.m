//
//  QRView.m
//  QRWeiXinDemo
//
//  Created by lovelydd on 15/4/25.
//  Copyright (c) 2015年 lovelydd. All rights reserved.
//

#import "QRView.h"
#define WindowWidth ([UIApplication sharedApplication].keyWindow.bounds.size.width)
#define WindowHeight ([UIApplication sharedApplication].keyWindow.bounds.size.height)



@implementation QRView
{

        UIImageView *qrLine;
        CGFloat qrLineY;
        int num;
        BOOL upOrdown;
        UIImageView *imageView;
        UIImageView  *biank;
}


- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        self.opaque = NO;
        
    }
    return self;
}


- (void)layoutSubviews {
    
    [super layoutSubviews];
    if (!qrLine) {
        
        [self initQRLine];
        
       
    }
    
   
}

- (void)initQRLine {
    
    imageView = [[UIImageView alloc]initWithFrame:CGRectMake((WindowWidth-258)/2-2, 154-2, 262, 262)];
    imageView.image = [UIImage imageNamed:@"bian-"];
    [self addSubview:imageView];
   
    biank = [[UIImageView alloc]initWithFrame:CGRectMake((WindowWidth-258)/2, 154, 258, 258)];
    biank.image = [UIImage imageNamed:@"kuan-xian-"];
    [self addSubview:biank];
    
}


- (void)drawRect:(CGRect)rect {
    
    [[UIColor colorWithWhite:0 alpha:0.5] setFill];
    //半透明区域
    UIRectFill(rect);
    
    //透明的区域
    CGRect holeRection = CGRectMake((WindowWidth-258)/2, 154, 258, 258);
    /** union: 并集
     CGRect CGRectUnion(CGRect r1, CGRect r2)
     返回并集部分rect
     */
    
    /** Intersection: 交集
     CGRect CGRectIntersection(CGRect r1, CGRect r2)
     返回交集部分rect
     */
    CGRect holeiInterSection = CGRectIntersection(holeRection, rect);
    [[UIColor clearColor] setFill];
    
    //CGContextClearRect(ctx, <#CGRect rect#>)
    //绘制
    //CGContextDrawPath(ctx, kCGPathFillStroke);
    UIRectFill(holeiInterSection);
    
}


@end
