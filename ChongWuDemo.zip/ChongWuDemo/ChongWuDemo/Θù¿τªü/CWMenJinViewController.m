//
//  CWMenJinViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWMenJinViewController.h"
#import "QRView.h"
@interface CWMenJinViewController ()<UIAlertViewDelegate>
{
    UIImageView *line;
    
}
@property(nonatomic,strong)UIView *backview;
@property(nonatomic,strong)UIButton *photo;
@property(nonatomic,strong)UIButton *imprtphot;
@property(nonatomic,strong)UIView *background;
@property(nonatomic,strong)UIView *backcamera;
@property (strong, nonatomic) CIDetector *detector;
@property (strong, nonatomic) AVAudioPlayer *beepPlayer;
@end



@implementation CWMenJinViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setNaviTitle:@"门禁二维码" leftButtonShow:NO rightButtom:nil];
    self.view.backgroundColor=[UIColor blackColor];
    
    NSString *mediaType = AVMediaTypeVideo;
    
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    
    if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"没有相机权限" message:@"请去设置-隐私-相机中对爱儿邦授权" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [alertController addAction:okAction];
        
        hasCameraRight = NO;
        return;
    }
    hasCameraRight = YES;
    
    upOrdown = NO;
    num =0;
    line = [[UIImageView alloc] initWithFrame:CGRectMake((kScreenW-258)/2, 154, 258, 2)];
    line.image = [UIImage imageNamed:@"扫线"];
    [self setupCamera];
    [self start];
    
}


- (UIView *)backview
{
    if (!_backview) {
        _backview = [[UIView alloc]initWithFrame:CGRectMake((kScreenW-200)/2, 460, 200, 45)];
        _backview.backgroundColor=[UIColor colorWithHexString:@"#000000"];
        _backview.alpha=0.6;
        _backview.layer.masksToBounds = YES;
        _backview.layer.cornerRadius = 8.0;
        [self.view addSubview:_backview];
        [_backview addSubview:self.imprtphot];
        [_backview addSubview:self.photo];
    }
    return _backview;
}
- (UIButton *)photo{
    if(!_photo){
        _photo=[UIButton buttonWithType:UIButtonTypeCustom];
        _photo.frame=CGRectMake(8, 5, 38, 30);
        [_photo setBackgroundImage:[UIImage imageNamed:@"xiang-pian-"] forState:UIControlStateNormal];
        [_photo addTarget:self action:@selector(import) forControlEvents:UIControlEventTouchUpInside];
    }
    return _photo;
    
}
- (UIButton *)imprtphot{
    
    if(!_imprtphot){
        _imprtphot=[UIButton buttonWithType:UIButtonTypeCustom];
        _imprtphot.frame=CGRectMake(46, 0, 150, 45);
        [_imprtphot setTitle:@"从相册导入二维码" forState:UIControlStateNormal];
        [_imprtphot setTitleColor:[UIColor colorWithHexString:@"#EEEEEE"] forState:UIControlStateNormal];
        [_imprtphot addTarget:self action:@selector(import) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _imprtphot;
}

-(void)animation1
{
    if (upOrdown == NO) {
        num ++;
        line.frame = CGRectMake(CGRectGetMinX(line.frame), 174+2*num, CGRectGetWidth( line.frame), CGRectGetHeight( line.frame));
        if (2 * num == 260 - 20) {
            upOrdown = YES;
        }
    }
    else {
        num --;
        line.frame = CGRectMake(CGRectGetMinX( line.frame), 154+2*num, CGRectGetWidth( line.frame), CGRectGetHeight( line.frame));
        if (num == 0) {
            upOrdown = NO;
        }
    }
    
}



-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
}
- (void)start{
    
    timer = [NSTimer scheduledTimerWithTimeInterval:.02 target:self selector:@selector(animation1) userInfo:nil repeats:YES];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //[timer invalidate];
    
}

- (void)setupCamera
{
    
    // Device
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    // Input
    _input = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:nil];
    
    // Output
    _output = [[AVCaptureMetadataOutput alloc]init];
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    // Session
    _session = [[AVCaptureSession alloc]init];
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    if ([_session canAddInput:self.input])
    {
        [_session addInput:self.input];
    }
    
    if ([_session canAddOutput:self.output])
    {
        [_session addOutput:self.output];
    }
    
    // 条码类型 AVMetadataObjectTypeQRCode
    _output.metadataObjectTypes =@[AVMetadataObjectTypeQRCode];
    // Preview
    _preview =[AVCaptureVideoPreviewLayer layerWithSession:self.session];
    _preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _preview.frame = self.view.bounds;
    [self.view.layer insertSublayer:self.preview atIndex:0];
    
    // Start
    [_session startRunning];
    CGRect screenRect = [UIScreen mainScreen].bounds;
    QRView *qrRectView = [[QRView alloc] initWithFrame:screenRect];
    qrRectView.transparentArea = CGSizeMake(258, 258);
    
    [self.view addSubview:qrRectView];
    [self.view addSubview:line];
//    [self.view addSubview:self.backview];//
    
}

#pragma mark AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    
    
    NSString *stringValue;
    
    if (metadataObjects != nil && [metadataObjects count] >0)
    {
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex:0];
        stringValue = metadataObject.stringValue;
        
        
       
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请对准小区门禁二维码哦！" delegate:self cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
            alert.delegate=self;
            alert.tag=10;
            [alert show];
            [_session stopRunning];
            [timer invalidate];
        }
        
        
    
    
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if(buttonIndex==0 ){
        [_session startRunning];
        [self start];
    }
    
}
#pragma mark - Checking RightBarButtonItem
- (void)import{
    
    self.detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{ CIDetectorAccuracy : CIDetectorAccuracyHigh }];
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = NO;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self.navigationController presentViewController:picker animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info
{
    [picker dismissViewControllerAnimated:NO completion:nil];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    if (!image){
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    
    
    NSArray *features = [self.detector featuresInImage:[CIImage imageWithCGImage:image.CGImage]];
    if(features.count==0){
    }
    if (features.count >=1) {
        CIQRCodeFeature *feature = [features objectAtIndex:0];
        NSString *scannedResult = feature.messageString;
        
        
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请对准小区门禁二维码哦!" delegate:self cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
            [alert show];
            alert.delegate=self;
            [_session stopRunning];
            [timer invalidate];
            
        
    }
}

- (void)back{
    
    [self dismissViewControllerAnimated:NO completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

