//
//  CWOrderViewController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWOrderViewController.h"
#import "CWOrderCell.h"
#import "HBTitleView.h"
#import "CWOrderDetailController.h"
@interface CWOrderViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *_datasource;
    NSInteger _types;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (strong, nonatomic) HBTitleView *hbTitleView;//top
@end

@implementation CWOrderViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
    [_datasource removeAllObjects];
    [self.tableview reloadData];
    [self.tableview.mj_header beginRefreshing];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setNaviTitle:@"我的工单" leftButtonShow:NO rightButtom:nil];
     _datasource=[NSMutableArray array];
    [self.view addSubview:self.hbTitleView];
    [self setUITableview];
    self.hbTitleView.titleBtnBlock = ^(NSInteger index, NSString *title) {
        
        if(index==0){
            
            _types=0;
            [_datasource removeAllObjects];
            [_tableview reloadData];
            [_tableview.mj_header beginRefreshing];;
        }else{
            _types=1;
            [_datasource removeAllObjects];
            [_tableview reloadData];
            [_tableview.mj_header beginRefreshing];;
        }
    };
}

- (void)getdata{
    
    if(_types==0){
        [_datasource addObjectsFromArray :@[@{@"adress":@"W区1栋102",
                                              @"date":@"2019-09-10",
                                              @"pay":@"120¥",
                                              @"people":@"王先生",
                                              @"question":@"热水器一直加热很慢的问题",
                                              @"tel":@"15843564432",
                                              @"top":@"已处理",
                                              @"color":@"#43CD80",
                                              @"remark":@"麻烦快一点哈",
                                              @"img":@"wy1"
                                              },
                                            @{@"adress":@"W区2栋402",
                                              @"date":@"2019-09-08",
                                              @"pay":@"120¥",
                                              @"people":@"李先生",
                                              @"question":@"小区门禁打不开",
                                              @"tel":@"15979984432",
                                              @"top":@"已处理",
                                              @"color":@"#43CD80",
                                              @"remark":@"动作要快，姿势要帅",
                                              @"img":@"wy2"
                                              },
                                            @{@"adress":@"W区3栋102",
                                              @"date":@"2019-09-05",
                                              @"pay":@"190¥",
                                              @"people":@"刘小姐",
                                              @"question":@"小区下水道堵",
                                              @"tel":@"18933524432",
                                              @"top":@"已处理",
                                              @"color":@"#43CD80",
                                              @"remark":@"情况紧急，加快速度",
                                              @"img":@"wy3"
                                              },
                                            @{@"adress":@"W区1栋102",
                                              @"date":@"2019-09-09",
                                              @"pay":@"160¥",
                                              @"people":@"刘先生",
                                              @"question":@"马桶堵住了啊的问题",
                                              @"tel":@"15843564432",
                                              @"top":@"已处理",
                                              @"color":@"#43CD80",
                                              @"remark":@"催了哈几天了啊，能不能尽点力气",
                                              @"img":@"wy4"
                                              },
                                            @{@"adress":@"W区1栋102",
                                              @"date":@"2019-09-08",
                                              @"pay":@"150¥",
                                              @"people":@"武先生",
                                              @"question":@"天然气无法正常使用",
                                              @"tel":@"15843564432",
                                              @"top":@"已处理",
                                              @"color":@"#43CD80",
                                              @"remark":@"再不来修理，就没饭吃了啊",
                                              @"img":@"wy5"
                                              }]];
    }else{
        
        [_datasource addObjectsFromArray :@[@{@"adress":@"花园小区1栋106",
                                              @"date":@"2019-09-10",
                                              @"pay":@"120¥",
                                              @"people":@"王先生",
                                              @"question":@"空调一直在滴水",
                                              @"tel":@"15843564432",
                                              @"top":@"未处理",
                                              @"color":@"#FF0000",
                                              @"remark":@"有几天了哦，要赶紧处理一下",
                                              @"img":@"wyorder11",
                                              @"id":@"44729480348384",
                                              @"shifu":@"刘师傅",
                                              },
                                            @{@"adress":@"留仙洞区A栋602",
                                              @"date":@"2019-09-09",
                                              @"pay":@"150¥",
                                              @"people":@"李先生",
                                              @"question":@"停车位不足",
                                              @"tel":@"15979984432",
                                              @"top":@"未处理",
                                              @"color":@"#FF0000",
                                              @"remark":@"每次下班回来都没地方停车了",
                                              @"img":@"wyorder12",
                                               @"id":@"24839579484085",
                                              @"shifu":@"李师傅",
                                              },
                                            @{@"adress":@"西丽小区B栋101",
                                              @"date":@"2019-09-10",
                                              @"pay":@"290¥",
                                              @"people":@"刘小姐",
                                              @"question":@"垃圾堆放太多了，气味很大啊",
                                              @"tel":@"18933524432",
                                              @"top":@"未处理",
                                              @"color":@"#FF0000",
                                              @"remark":@"这个关系到大家的问题，希望赶紧处理一下谢谢",
                                              @"img":@"wyorder13",
                                               @"id":@"343947294348",
                                              @"shifu":@"康师傅",
                                              },
                                            
                                             ]];
    }
    [self.tableview reloadData];
}
- (HBTitleView *)hbTitleView
{
    if (_hbTitleView == nil)
    {
        
        _hbTitleView = [[HBTitleView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 45) andTitles:@[@"已处理",@"未处理"]];
        
        [_hbTitleView updataIndexLabelUIWithNum:0];
    }
    return _hbTitleView;
}
- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWOrderCell" bundle:nil] forCellReuseIdentifier:@"CWOrderCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [_tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self getdata];
        }else{
            
            [SVProgressHUD showErrorWithStatus:@"暂无工单数据!"];
            
            
        }
    });
}




#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 110;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CWOrderCell";
    
    CWOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[CWOrderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    if(_datasource.count>0){
        NSDictionary *dict=_datasource[indexPath.row];
        cell.namelb.text=dict[@"adress"];
        cell.titlelb.text=dict[@"question"];
        cell.img.image=[UIImage imageNamed:dict[@"img"]];
        cell.datelb.text=dict[@"date"];
        [cell.selectbtn setTitle:dict[@"top"] forState:UIControlStateNormal];
        cell.selectbtn.layer.masksToBounds=YES;
        cell.selectbtn.layer.cornerRadius=8;
        if(_types==0){
            [cell.selectbtn setBackgroundColor:[UIColor colorWithHexString:@"#00CD00"]];
            
        }else{
            [cell.selectbtn setBackgroundColor:[UIColor redColor]];
        }
        
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CWOrderDetailController *vc=[[CWOrderDetailController alloc]init];
    NSDictionary *dict=_datasource[indexPath.row];
    vc.dict=dict;
    [self pushViewController:vc];
    
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

