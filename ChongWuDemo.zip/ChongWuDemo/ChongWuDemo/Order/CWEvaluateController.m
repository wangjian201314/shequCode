//
//  CWEvaluateController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWEvaluateController.h"
#import "CWEvaluateCell.h"
#import "CWPingLunController.h"
@interface CWEvaluateController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_datasource;
    NSArray *_titlearr;
    NSArray *_datas;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong) UIButton *sendbtn;
@end

@implementation CWEvaluateController


- (UIButton *)sendbtn{
    
    if(!_sendbtn){
        _sendbtn=[[UIButton alloc]initWithFrame:CGRectMake(30, kScreenH-kTabarHeight-70,kScreenW-60, 45)];
        [_sendbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _sendbtn.layer.masksToBounds = YES;
        [_sendbtn setTitle:@"去评价" forState:UIControlStateNormal];
        [_sendbtn setBackgroundColor:[UIColor colorWithHexString:@"#6495ED"]];
        _sendbtn.layer.cornerRadius = 8.0;
        [_sendbtn addTarget:self action:@selector(upload) forControlEvents:UIControlEventTouchUpInside];
        
        
        
    }
    return _sendbtn;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"评论" leftButtonShow:YES rightButtom:nil];
//    _datasource=[NSMutableArray array];
    [self setUI];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self setdata];
            [self.view addSubview:self.sendbtn];
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无评价数据!"];
        }
    });
    
}

- (void)setUI{
    
    _tableview.delegate=self;
    _tableview.dataSource=self;
    _tableview.rowHeight=UITableViewAutomaticDimension;
    _tableview.estimatedRowHeight=200;
    _tableview.showsVerticalScrollIndicator=NO;
    _tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [_tableview registerNib:[UINib nibWithNibName:@"CWEvaluateCell" bundle:nil] forCellReuseIdentifier:@"CWEvaluateCell"];
    
    
}

- (void)setdata{
    
    if(_types==0){
        
        _datasource=@[@{@"title":@"小区单元101空调维修",
                        @"time":@"2019-09-07 14:25",
                        @"star":@"四星",
                        @"content":@"备注：张师傅挺好的，下单后就立马赶过来了，也不问管是天气好天气坏就过来，在这路很感谢张师傅"
                        
                        }];
    }else if(_types==1){
        
        _datasource=@[@{@"title":@"小区下水道堵塞",
                        @"time":@"2019-09-08 17:30",
                        @"star":@"一星",
                        @"content":@"备注：张师傅服务一般吧，下单后都过了一天还不来服务，真的是无话可说，希望下次不会碰到，还望平台督查"
                        
                        }];
    }else if(_types==2){
        
        _datasource=@[@{@"title":@"马桶堵住了啊的问题",
                        @"time":@"2019-09-09 16:25",
                        @"star":@"五星",
                        @"content":@"备注：我觉得平台的张师傅挺好的，谁遇到谁幸运，哈哈"
                        
                        },
                      @{@"title":@"热水器一直加热很慢的问题",
                        @"time":@"2019-09-11 14:00",
                        @"star":@"四星",
                        @"content":@"备注：张师傅不知道是不是因为年纪大了还是什么，沟通无法沟通，简直让人服了，就这么多了，啥都不说，谢谢！"
                        
                        }];
    }else if(_types==3){
        
        _datasource=@[@{@"title":@"热水器一直加热很慢的问题",
                        @"time":@"2019-09-11 14:00",
                        @"star":@"四星",
                        @"content":@"备注：张师傅不知道是不是因为年纪大了还是什么，沟通无法沟通，简直让人服了，就这么多了，啥都不说，谢谢！"
                        
                        },
                      @{@"title":@"天然气无法正常使用",
                        @"time":@"2019-09-010 19:45",
                        @"star":@"四星",
                        @"content":@"备注：还能说啥，只能说师傅们都是大爷，我们客户是儿子吧，哈哈！此处省略一万字。。。。。"
                        
                        }];
    }else{
        
        _datasource=@[@{@"title":@"天然气无法正常使用",
                        @"time":@"2019-09-010 19:45",
                        @"star":@"四星",
                        @"content":@"备注：还能说啥，只能说师傅们都是大爷，我们客户是儿子吧，哈哈！此处省略一万字。。。。。"
                        
                        },
                      @{@"title":@"小区下水道堵塞",
                        @"time":@"2019-09-08 17:30",
                        @"star":@"一星",
                        @"content":@"备注：张师傅服务一般吧，下单后都过了一天还不来服务，真的是无话可说，希望下次不会碰到，还望平台督查"
                        
                        }];
    }
    
    
    [_tableview reloadData];
}
#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 190;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    CWEvaluateCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CWEvaluateCell"];
    
    if(cell == nil) {
        cell = [[CWEvaluateCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"EvaluateCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    NSDictionary *dict=_datasource[indexPath.row];
    cell.namelb.text=dict[@"star"];
    cell.secondlb.text=dict[@"title"];
    cell.thirdlb.text=dict[@"time"];
    cell.lastlb.text=dict[@"content"];
    
    return cell;
}


- (void)upload{
    
    CWPingLunController *vc=[CWPingLunController new];
    [self pushViewController:vc];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
