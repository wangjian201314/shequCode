//
//  CWEvaluateCell.h
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWEvaluateCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *secondlb;
@property (weak, nonatomic) IBOutlet UILabel *thirdlb;
@property (weak, nonatomic) IBOutlet UILabel *lastlb;

@end

NS_ASSUME_NONNULL_END
