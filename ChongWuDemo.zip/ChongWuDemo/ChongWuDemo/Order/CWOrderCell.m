//
//  CWOrderCell.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWOrderCell.h"

@implementation CWOrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.img.layer.masksToBounds=YES;
    self.img.layer.cornerRadius=8;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
