//
//  CWOderDetailCell.h
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWOderDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *detaillb;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *widthconstant;

@end

NS_ASSUME_NONNULL_END
