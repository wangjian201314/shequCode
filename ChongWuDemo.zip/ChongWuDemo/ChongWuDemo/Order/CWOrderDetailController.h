//
//  CWOrderDetailController.h
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CWOrderDetailController : MTBaseViewController

@property (nonatomic,strong)NSDictionary *dict;
@end

NS_ASSUME_NONNULL_END
