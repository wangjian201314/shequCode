//
//  CWOrderFinishController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWOrderFinishController.h"

@interface CWOrderFinishController ()
@property (weak, nonatomic) IBOutlet UILabel *toplb;
@property (weak, nonatomic) IBOutlet UILabel *datelb;
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *tellb;
@property (weak, nonatomic) IBOutlet UIButton *finishibtn;
@property (weak, nonatomic) IBOutlet UIImageView *img;

@end

@implementation CWOrderFinishController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"提交订单" leftButtonShow:YES rightButtom:nil];
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
    self.toplb.hidden=YES;
    self.datelb.hidden=YES;
    self.namelb.hidden=YES;
    self.tellb.hidden=YES;
    self.finishibtn.hidden=YES;
    self.img.hidden=YES;
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *nowDateString = [dateFormatter stringFromDate:[NSDate date]];
        [SVProgressHUD dismiss];
        self.toplb.hidden=NO;
        self.datelb.hidden=NO;
        self.namelb.hidden=NO;
        self.tellb.hidden=NO;
        self.finishibtn.hidden=NO;
        self.img.hidden=NO;
        self.toplb.text=[NSString stringWithFormat:@"工单编号:,%@",_dict[@"id"]];
        self.datelb.text=[NSString stringWithFormat:@"提交时间:,%@",nowDateString];
        self.namelb.text=[NSString stringWithFormat:@"处理人:,%@",_dict[@"shifu"]];
        self.tellb.text=[NSString stringWithFormat:@"联系电话:,%@",_dict[@"tel"]];
    });
    
}

- (IBAction)finishibtn:(UIButton *)sender {
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        
        [self.finishibtn setTitle:@"已提交" forState:UIControlStateNormal];
        [self.finishibtn setBackgroundColor:[UIColor grayColor]];
        self.finishibtn.enabled=NO;
        if(self.delegate && [self.delegate respondsToSelector:@selector(didSelectedOrderEditCell)]){
            
            [self.delegate didSelectedOrderEditCell];
        }
        [self backAction];
    });
    

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
