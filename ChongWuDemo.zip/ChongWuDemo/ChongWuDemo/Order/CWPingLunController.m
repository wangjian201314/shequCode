//
//  CWPingLunController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWPingLunController.h"
#import "UITextView+Placeholder.h"
@interface CWPingLunController ()
@property (weak, nonatomic) IBOutlet UITextView *textview;
@property (weak, nonatomic) IBOutlet UIButton *uploadbtn;
@property (weak, nonatomic) IBOutlet UIButton *photobtn;

@end

@implementation CWPingLunController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"提交评论" leftButtonShow:YES rightButtom:nil];
    _uploadbtn.layer.cornerRadius = 8.0;
    _uploadbtn.layer.masksToBounds = YES;
    self.textview.layer.cornerRadius = 8.0;
    self.textview.layer.borderColor = [UIColor colorWithHexString:@"#4994F4"].CGColor;
    self.textview.layer.borderWidth = 1;
    self.textview.layer.masksToBounds = YES;
    [_textview setPlaceHolder:@"请输入您的评论(不超过100字)。。。"];
}
- (IBAction)photobtn:(UIButton *)sender {
    
    [self recognize];
    
}
- (IBAction)uploadbtn:(UIButton *)sender {
    
    if([self.textview.text isEqualToString:@""] || self.textview.text.length==0){
        [SVProgressHUD showErrorWithStatus:@"评论不能为空哦"];
         dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
        return;
    }
    [SVProgressHUD showWithStatus:@"正在提交。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [SVProgressHUD showSuccessWithStatus:@"提交成功！"];
    });
    
}


#pragma mark--更换头像
- (void)recognize{
    
    
        UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
        sheet.delegate=self;
        [sheet showInView:self.view];
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [self presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    [self.photobtn setImage:image forState:UIControlStateNormal];
   
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
