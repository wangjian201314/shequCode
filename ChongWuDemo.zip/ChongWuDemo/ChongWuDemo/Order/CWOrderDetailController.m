//
//  CWOrderDetailController.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/13.
//  Copyright © 2019 王健. All rights reserved.
//

#import "CWOrderDetailController.h"
#import "CWOrderTopCell.h"
#import "CWOderDetailCell.h"
#import "CWOrderFinishController.h"
#import "CWEvaluateController.h"
@interface CWOrderDetailController ()<UITableViewDelegate,UITableViewDataSource,JXOrderEditCellDelegate>{
    
    NSArray *_titledata;
     NSArray *_titlekey;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong) UIButton *sendbtn;
@end

@implementation CWOrderDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNaviTitle:@"工单详情" leftButtonShow:YES rightButtom:nil];
    [self setUITableview];
    
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"CWOrderTopCell" bundle:nil] forCellReuseIdentifier:@"CWOrderTopCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"CWOderDetailCell" bundle:nil] forCellReuseIdentifier:@"CWOderDetailCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.estimatedRowHeight=44;
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [self.tableview.mj_header beginRefreshing];
    [self.view addSubview:self.sendbtn];
}

- (void)headerRefresh{
    
    [SVProgressHUD showWithStatus:@"正在加载。。。"];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
        [SVProgressHUD dismiss]; _titledata=@[@"img",@"问题:",@"地址:",@"报修人:",@"报修时间:",@"电话:",@"社区:",@"备注:"];
        _titlekey=@[@"img",@"question",@"adress",@"people",@"date",@"tel",@"adress",@"remark"];
        if([_dict[@"top"] isEqualToString:@"未处理"]){
            [self.sendbtn setTitle:@"等待维修人员接单!" forState:UIControlStateNormal];
        }else{
            [self.sendbtn setTitle:@"已接单" forState:UIControlStateNormal];
        }
        
        [self.sendbtn setBackgroundColor:[UIColor colorWithHexString:_dict[@"color"]]];
        [self.tableview reloadData];
    });
}

- (UIButton *)sendbtn{
    
    if(!_sendbtn){
        _sendbtn=[[UIButton alloc]initWithFrame:CGRectMake(30, kScreenH-kTabarHeight-70,kScreenW-60, 45)];
        [_sendbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _sendbtn.layer.masksToBounds = YES;
        _sendbtn.layer.cornerRadius = 8.0;
        [_sendbtn addTarget:self action:@selector(upload) forControlEvents:UIControlEventTouchUpInside];
        
        
        
    }
    return _sendbtn;
}

- (void)upload{
    if([_dict[@"top"] isEqualToString:@"未处理"]){
        
        CWOrderFinishController *vc=[CWOrderFinishController new];
        vc.dict=_dict;
        vc.delegate=self;
        [self pushViewController:vc];
       
    }else{
        
        CWEvaluateController *vc=[CWEvaluateController new];
        [self pushViewController:vc];
    }
    
    
}
#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _titledata.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==0){
        return 200;
    }else{
        return 44;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(indexPath.row==0){
        static NSString *cellIdentifier = @"CWOrderTopCell";
        
        CWOrderTopCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWOrderTopCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        cell.img.image=[UIImage imageNamed:_dict[_titlekey[indexPath.row]]];
        return cell;
    }else{
        static NSString *cellIdentifier = @"CWOderDetailCell";
        
        CWOderDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[CWOderDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.namelb.text=_titledata[indexPath.row];
        cell.detaillb.text=_dict[_titlekey[indexPath.row]];
        CGSize size = [cell.namelb.text boundingRectWithSize:CGSizeMake(200, MAXFLOAT)
                                              options:NSStringDrawingUsesLineFragmentOrigin
                                           attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]}
                                              context:nil].size;
        cell.widthconstant.constant=size.width;
      
        return cell;
        
    }
    
    
}


- (void)didSelectedOrderEditCell{
    
    [self.sendbtn setBackgroundColor:[UIColor grayColor]];
    [self.sendbtn setTitle:@"已经提交订单" forState:UIControlStateNormal];
    self.sendbtn.enabled=NO;
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
