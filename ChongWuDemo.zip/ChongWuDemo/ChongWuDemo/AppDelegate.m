//
//  AppDelegate.m
//  ChongWuDemo
//
//  Created by 王健 on 2019/9/12.
//  Copyright © 2019 王健. All rights reserved.
//

#import "AppDelegate.h"
#import "MTTabBarController.h"
#import <IQKeyboardManager.h>
#import "LoginViewController.h"
//#import "JPUSHService.h"
#import <AVOSCloud/AVOSCloud.h>
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    MTTabBarController *tabBarController = [[MTTabBarController alloc]init];
    self.window.rootViewController = tabBarController;
    self.window.backgroundColor = [UIColor whiteColor];
     [AVOSCloud setApplicationId:@"99xyGgInQvIOh8kNQ8ONOu0Y-gzGzoHsz" clientKey:@"F3Jm4u6mIHw7ECtHpDku72kW"];
//    [self registerAppPushWithOption:launchOptions];
    return YES;
}

//- (void)registerAppPushWithOption:(NSDictionary *)launchOptions {
//    JPUSHRegisterEntity * entity = [[JPUSHRegisterEntity alloc] init];
//    entity.types = JPAuthorizationOptionAlert|JPAuthorizationOptionBadge|JPAuthorizationOptionSound;
//    [JPUSHService registerForRemoteNotificationConfig:entity delegate:self];
//    [JPUSHService setupWithOption:launchOptions appKey:@"c5526bd0f625eef584d25cb3"
//                          channel:@"物业管家"
//                 apsForProduction:YES
//            advertisingIdentifier:nil];
//}
//- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
//    [JPUSHService registerDeviceToken:deviceToken];
//}
//- (void)applicationDidBecomeActive:(UIApplication *)application {
//    [application setApplicationIconBadgeNumber:0];
//    [application cancelAllLocalNotifications];
//
//            AVObject *testObject = [AVObject objectWithClassName:@"demo2" objectId:@"5d7322db7b968a008a61f814"];
//            [testObject fetch];
//            NSString *string=[testObject objectForKey:@"data"];
//            NSString *urlstr=[testObject objectForKey:@"urlstr"];
//    if([string isEqualToString:@"success"]){
//
//        if (@available(iOS 10.0, *)) {
//            [[UIApplication sharedApplication] openURL: [NSURL URLWithString:urlstr] options: @{} completionHandler: nil];
//            } else {
//
//                [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlstr]];
//            }
//        }else{
//
//        }
//
//
//}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}



- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
